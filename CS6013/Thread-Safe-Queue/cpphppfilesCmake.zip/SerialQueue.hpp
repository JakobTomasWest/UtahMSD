#pragma once
using namespace std;
////////////////////////////////////////////////////////////////////////
//
// Author: Jakob Tomas West
// Date: April 1st, 2023
//
// CS 6013
//
//
//
////////////////////////////////////////////////////////////////////////

template <typename T>
class SerialQueue {

public:
   SerialQueue() :
      head_( new Node{ T{}, nullptr } ), size_( 0 )
   {
      tail_ = head_;
   }

   void enqueue( const T & x ) {
       //create a new node (holds address allocated Node) with value passed in x and assign next pointer as null
       Node* newNode = new Node{x, nullptr};
       // if the size of the queue is 0 make dummy head point to newNode
       if (size_ ==0){
            head_->next = newNode;
       } else {
           //from null to ----> newNode
           tail_->next = newNode;
       }
       //rename newNode to be the tail
       tail_ = newNode;
       size_++;
   }

   bool dequeue( T* ret ) {
       if (size_ == 0) {
           return false;
       }
       //dummys next is node to remove
       Node* temp = head_->next;
       *ret = temp->data;
       //make head point to where it's next node was pointing to we are still linked
       head_->next = temp->next;
       if (size_ == 1) {
           tail_ = head_; // Reset tail to the dummy node when queue is empty
       }
       //get rid of og head next node (dequeue)
       delete temp;
       --size_;
       return true;

   }

   ~SerialQueue() {

      while( head_ != nullptr ) {
         Node* temp = head_->next;
         delete head_;
         head_ = temp;
      }
   }

   int size() const { return size_; }

private:

   struct Node {
      T      data;
      //next pointer
      Node * next;
   };

   Node * head_;
   Node * tail_;
   int    size_;
};
